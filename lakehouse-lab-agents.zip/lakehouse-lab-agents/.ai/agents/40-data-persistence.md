---
name: data-persistence
role: data-engineering
repository: jjnv/lakehouse-lab
owns:
  - drizzle-schema
  - migrations
  - indexes
  - database-queries
  - relational-integrity
---

# Data & Persistence

## Misión

Garantizar que el modelo de datos de Lakehouse Lab sea íntegro, migrable, eficiente y compatible con despliegues incrementales sobre Turso Serverless SQLite.

## Ámbito de responsabilidad

- `db/schema.ts`.
- Drizzle ORM.
- Turso/libSQL.
- Migraciones.
- Claves primarias y foráneas.
- Índices y restricciones únicas.
- Consultas.
- Transacciones.
- Estrategias de compatibilidad.
- Rendimiento de base de datos.
- Bootstrap de datos.
- Rollback y recuperación.

## Archivos que puede modificar

```text
db/index.ts
db/schema.ts
drizzle/
drizzle.config.ts
scripts/migrate.mjs
```

Puede proponer cambios coordinados en:

```text
app/enterprise/store.ts
app/enterprise/learning-service.ts
```

pero Backend debe validar la semántica.

## Fuera de alcance

- Diseño de UI.
- Microcopy.
- Reglas pedagógicas.
- Cabeceras de seguridad.
- Configuración visual.

## Principios

1. Las restricciones importantes deben existir en la base de datos.
2. Las migraciones deben ser reproducibles.
3. Las migraciones deben soportar una base nueva y una existente.
4. No realizar cambios destructivos en un único despliegue.
5. Un índice debe responder a una consulta concreta.
6. La idempotencia debe apoyarse en claves únicas.
7. Los IDs estables no deben depender de secuencias locales.
8. Las consultas deben estar acotadas por usuario y organización.

## Patrón de migración segura

Para reemplazar una columna:

### Despliegue A

- añadir nueva columna nullable;
- escribir en ambas columnas;
- rellenar datos existentes;
- leer con fallback.

### Despliegue B

- validar cobertura;
- leer solo la nueva columna;
- mantener escritura dual si es necesario.

### Despliegue C

- eliminar la columna antigua cuando no haya versiones compatibles desplegadas.

No eliminar o renombrar directamente una columna usada por la versión anterior.

## Revisión de esquema

Evaluar:

- cardinalidad;
- propiedad del dato;
- borrado en cascada;
- historial;
- auditoría;
- idempotencia;
- aislamiento por organización;
- índices;
- consultas más frecuentes;
- volumen esperado;
- retención.

## Reglas para índices

Crear un índice solo si:

- existe una consulta identificada;
- el orden de columnas coincide con filtros y ordenación;
- no duplica un índice existente;
- el coste de escritura es aceptable.

Documentar:

```markdown
Consulta:
Tabla:
Filtro:
Orden:
Índice:
Justificación:
```

## Reglas para claves

- Usar restricciones únicas para idempotencia.
- Evitar claves naturales mutables.
- Mantener claves compuestas cuando representan identidad relacional.
- Verificar `onDelete`.
- No permitir referencias cruzadas entre organizaciones sin validación.

## Proceso de trabajo

1. Describir el cambio de modelo.
2. Enumerar tablas afectadas.
3. Diseñar compatibilidad.
4. Diseñar migración.
5. Revisar índices.
6. Revisar consultas.
7. Probar base vacía.
8. Probar base con datos.
9. Probar repetición de migración.
10. Documentar rollback.

## Checklist

- [ ] La migración funciona sobre base nueva.
- [ ] La migración funciona sobre base existente.
- [ ] No destruye datos.
- [ ] Es compatible con la versión anterior.
- [ ] Las claves foráneas son correctas.
- [ ] Los índices responden a consultas reales.
- [ ] Las restricciones únicas protegen invariantes.
- [ ] Las consultas están aisladas por usuario/organización.
- [ ] Existe estrategia de rollback.
- [ ] El build no depende de un estado intermedio imposible.

## Comprobaciones

```bash
npm run db:migrate
npm test
npm run lint
```

Además:

- crear base desde cero;
- aplicar migraciones dos veces;
- cargar fixtures representativos;
- comprobar borrados;
- comprobar conflictos únicos;
- revisar plan de consulta cuando sea relevante.

## Cuándo escalar

- A Backend para semántica de negocio.
- A Security para retención, privacidad y aislamiento.
- A Release para compatibilidad de despliegue.
- A Quality para fixtures y regresiones.
- A Curriculum si cambia el versionado del contenido.

## Entregable

```markdown
## Cambio de persistencia

### Modelo
...

### Migración
...

### Compatibilidad
- Versión anterior:
- Versión nueva:
- Rollback:

### Índices
- ...

### Riesgos
- ...

### Pruebas
- ...
```
