# Agentes de ingeniería de Lakehouse Lab

Este documento define el sistema de agentes especializado para el repositorio `jjnv/lakehouse-lab`.

El objetivo no es que todos los agentes intervengan en todas las tareas. Cada cambio debe tener:

- **un agente propietario**;
- **cero, uno o dos revisores**, según el riesgo;
- criterios de aceptación verificables;
- evidencia concreta en archivos, símbolos, rutas y pruebas.

## Principios generales

1. **El servidor es autoritativo.** El navegador no decide identidad, progreso, puntuaciones, desbloqueos ni credenciales.
2. **El currículo está versionado como código.** No debe tratarse como contenido dinámico de base de datos.
3. **Los Route Handlers son adaptadores finos.** La lógica de negocio pertenece a `app/enterprise/`.
4. **Las mutaciones deben ser idempotentes y resistentes a concurrencia.**
5. **Las claves de respuestas nunca deben llegar al cliente antes de la corrección.**
6. **Las migraciones deben ser compatibles con despliegues incrementales.**
7. **Accesibilidad, privacidad y aislamiento entre usuarios son requisitos funcionales.**
8. **El build no sustituye a las pruebas.**

## Catálogo de agentes

| Archivo | Agente | Responsabilidad principal |
|---|---|---|
| `00-orchestrator.md` | Orchestrator | Delimitar, asignar y consolidar el trabajo |
| `10-product-ux.md` | Product UX | Flujos, arquitectura de información y claridad |
| `20-frontend-accessibility.md` | Frontend & Accessibility | React, Next.js, responsive y WCAG |
| `30-backend-domain-api.md` | Backend Domain & API | Casos de uso, contratos y reglas de negocio |
| `40-data-persistence.md` | Data & Persistence | Drizzle, Turso, esquema y migraciones |
| `50-security-privacy.md` | Security & Privacy | Modelo de amenazas, sesiones y privacidad |
| `60-curriculum-assessments.md` | Curriculum & Assessments | Contenido, preguntas y coherencia pedagógica |
| `70-quality-engineering.md` | Quality Engineering | Estrategia y ejecución de pruebas |
| `80-release-performance.md` | Release & Performance | Vercel, rendimiento y operabilidad |

## Selección del agente propietario

| Tipo de cambio | Propietario |
|---|---|
| Flujo, navegación o microcopy | Product UX |
| Componente, layout o interacción | Frontend & Accessibility |
| Endpoint, contrato o regla de progreso | Backend Domain & API |
| Tabla, índice, consulta o migración | Data & Persistence |
| Sesión, autorización o exposición de datos | Security & Privacy |
| Lección, banco de preguntas o evaluación | Curriculum & Assessments |
| Pruebas o regresiones | Quality Engineering |
| Build, despliegue o latencia | Release & Performance |

## Revisiones obligatorias

| Cambio | Revisores mínimos |
|---|---|
| Autenticación, sesión, permisos o privacidad | Security + Quality |
| Evaluaciones o certificados | Curriculum + Security + Quality |
| Migraciones | Data + Release + Quality |
| Contratos públicos de API | Backend + Frontend + Quality |
| Cambios importantes de navegación | Product + Frontend + Quality |
| Importación o eliminación de progreso | Backend + Security + Data + Quality |

## Reglas de edición

- Un archivo no debe ser modificado simultáneamente por dos agentes.
- El agente propietario propone y aplica el cambio.
- Los revisores señalan riesgos y pruebas; no reescriben todo el trabajo.
- Las decisiones irreversibles deben quedar registradas en la entrega.
- Las discrepancias se escalan al Orchestrator.
- Ningún agente debe afirmar que una prueba pasó si no la ejecutó.

## Comandos base

```bash
npm ci
npm run lint
npm test
npm run test:e2e
```

No todos los cambios requieren todos los comandos, pero la omisión debe justificarse.

## Formato estándar de entrega

Cada agente debe finalizar con:

```markdown
## Resultado

### Cambios realizados
- ...

### Evidencia
- `ruta/archivo.ts`: símbolo o comportamiento afectado.

### Pruebas ejecutadas
- `comando`: resultado.

### Riesgos residuales
- ...

### Decisiones pendientes
- ...
```
