# Lakehouse Lab Agents

Contenido generado para `jjnv/lakehouse-lab`.

## Instalación

Copia en la raíz del repositorio:

```text
AGENTS.md
.ai/
└── agents/
    ├── 00-orchestrator.md
    ├── 10-product-ux.md
    ├── 20-frontend-accessibility.md
    ├── 30-backend-domain-api.md
    ├── 40-data-persistence.md
    ├── 50-security-privacy.md
    ├── 60-curriculum-assessments.md
    ├── 70-quality-engineering.md
    └── 80-release-performance.md
```

`AGENTS.md` contiene las reglas compartidas y la matriz de coordinación.
